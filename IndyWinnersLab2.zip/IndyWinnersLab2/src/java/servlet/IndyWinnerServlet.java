package servlet;

import dao.IndyWinnerDAO;
import dao.IndyWinnerDAOImpl;
import dto.IndyWinner;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

/**
 * Servlet to handle requests for displaying Indy Winners.
 * Supports pagination and retrieves data using the DAO pattern.
 */
@WebServlet("/IndyWinnerServlet")
public class IndyWinnerServlet extends HttpServlet {

    /** DAO for accessing IndyWinners data. */
    private IndyWinnerDAO indyWinnerDAO;

    @Override
    public void init() throws ServletException {
        indyWinnerDAO = new IndyWinnerDAOImpl();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int page = 1;
        int resultsPerPage = 10;

        String pageParam = request.getParameter("page");
        if (pageParam != null) {
            try {
                page = Integer.parseInt(pageParam);
            } catch (NumberFormatException e) {
                page = 1;
            }
        }

        int offset = (page - 1) * resultsPerPage;
        List<IndyWinner> winners = indyWinnerDAO.getPaginatedWinners(offset, resultsPerPage);

        response.setContentType("text/html");

        try (PrintWriter out = response.getWriter()) {
            out.println("<html>");
            out.println("<head><title>Indy Winners</title></head>");
            out.println("<body>");
            out.println("<h1>Indianapolis 500 Winners</h1>");
            out.println("<table border='1'>");
            out.println("<tr><th>Year</th><th>Driver</th><th>Average Speed</th><th>Country</th></tr>");

            for (IndyWinner winner : winners) {
                out.println("<tr>");
                out.println("<td>" + winner.getYear() + "</td>");
                out.println("<td>" + winner.getDriver() + "</td>");
                out.println("<td>" + winner.getAverageSpeed() + "</td>");
                out.println("<td>" + winner.getCountry() + "</td>");
                out.println("</tr>");
            }

            out.println("</table>");
            if (page > 1) {
                out.println("<a href='IndyWinnerServlet?page=" + (page - 1) + "'>Previous</a> | ");
            }
            out.println("<a href='IndyWinnerServlet?page=" + (page + 1) + "'>Next</a>");
            out.println("</body>");
            out.println("</html>");
        }
    }
}
