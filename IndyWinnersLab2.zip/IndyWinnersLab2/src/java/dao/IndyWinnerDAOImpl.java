package dao;

import dto.IndyWinner;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementation of the IndyWinnerDAO interface using JDBC.
 */
public class IndyWinnerDAOImpl implements IndyWinnerDAO {

    /** Database URL. */
    private static final String URL = "jdbc:mysql://localhost:3306/indywinners?useSSL=false";

    /** Database username. */
    private static final String USER = "root";

    /** Database password. */
    private static final String PASSWORD = "Soufsor2_m";

    /**
     * Retrieves all Indy winners from the database.
     *
     * @return a list of all IndyWinner objects.
     */
    @Override
    public List<IndyWinner> getAllWinners() {
        List<IndyWinner> winners = new ArrayList<>();
        String query = "SELECT * FROM indywinners";

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery(query)) {

            while (rs.next()) {
                IndyWinner winner = new IndyWinner(
                        rs.getInt("year"),
                        rs.getString("driver"),
                        rs.getDouble("averagespeed"),
                        rs.getString("country")
                );
                winners.add(winner);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return winners;
    }

    /**
     * Retrieves a paginated list of Indy winners from the database.
     *
     * @param offset the starting point for retrieval.
     * @param limit the number of entries to retrieve.
     * @return a paginated list of IndyWinner objects.
     */
    @Override
    public List<IndyWinner> getPaginatedWinners(int offset, int limit) {
        List<IndyWinner> winners = new ArrayList<>();
        String query = "SELECT * FROM indywinners LIMIT ? OFFSET ?";

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement ps = connection.prepareStatement(query)) {

            ps.setInt(1, limit);
            ps.setInt(2, offset);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    IndyWinner winner = new IndyWinner(
                            rs.getInt("year"),
                            rs.getString("driver"),
                            rs.getDouble("averagespeed"),
                            rs.getString("country")
                    );
                    winners.add(winner);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return winners;
    }
}
