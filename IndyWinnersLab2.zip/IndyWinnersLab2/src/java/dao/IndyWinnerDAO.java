package dao;

import java.util.List;
import dto.IndyWinner;

/**
 * DAO interface for managing IndyWinner objects.
 * Provides methods to retrieve data from the database.
 */
public interface IndyWinnerDAO {

    /**
     * Retrieves all Indy winners from the database.
     *
     * @return a list of all IndyWinner objects.
     */
    List<IndyWinner> getAllWinners();

    /**
     * Retrieves a paginated list of Indy winners from the database.
     *
     * @param offset the starting point for retrieval.
     * @param limit the number of entries to retrieve.
     * @return a paginated list of IndyWinner objects.
     */
    List<IndyWinner> getPaginatedWinners(int offset, int limit);
}

