package dto;

/**
 * DTO class for representing an Indy Winner.
 */
public class IndyWinner {

    /** Year of the Indy 500 win. */
    private int year;

    /** Driver's name. */
    private String driver;

    /** Average speed achieved during the win. */
    private double averageSpeed;

    /** Country of the winning driver. */
    private String country;

    /**
     * Default constructor.
     */
    public IndyWinner() {}

    /**
     * Parameterized constructor.
     *
     * @param year the year of the win.
     * @param driver the name of the driver.
     * @param averageSpeed the average speed during the win.
     * @param country the country of the driver.
     */
    public IndyWinner(int year, String driver, double averageSpeed, String country) {
        this.year = year;
        this.driver = driver;
        this.averageSpeed = averageSpeed;
        this.country = country;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getDriver() {
        return driver;
    }

    public void setDriver(String driver) {
        this.driver = driver;
    }

    public double getAverageSpeed() {
        return averageSpeed;
    }

    public void setAverageSpeed(double averageSpeed) {
        this.averageSpeed = averageSpeed;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
}
